import os
os.environ['SIMPLE_SETTINGS'] = "tuf.settings"
