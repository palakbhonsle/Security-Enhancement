# Proposals #

## Accepted ##

## Rejected ##

## In Progress ##
* Trust pinning
* Multirole delegations
