This directory contains an example of a TUF repository, metadata, and key and
client files.

## WARNING ##
These examples were last updated 2 years ago. We have since made changes to the
format of our metadata and key files, and will need to regenerate them so the
new tools can properly load them. We are currently working on a 1.0 release
that will make further tweaks to the format of metadata and key files, so these
examples will be modified once again.

Note: The examples that are up-to-date and normally tested are located here:
https://github.com/theupdateframework/tuf/tree/develop/tests/repository_data/
